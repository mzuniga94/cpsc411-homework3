package com.csuf.cpsc411.homework_3.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.csuf.cpsc411.homework_3.R;
import com.csuf.cpsc411.homework_3.StudentDetailActivity;
import com.csuf.cpsc411.homework_3.model.Student;
import com.csuf.cpsc411.homework_3.model.StudentDB;

import java.util.ArrayList;

public class SummaryLVAdapter extends BaseAdapter {

    protected int count = 0;
    StudentDB mStudentDB;
    ArrayList<Student> mStudents;


    public SummaryLVAdapter(Context context){
        mStudentDB = new StudentDB(context);
        mStudentDB.retrieveStudentObjects();
}

    public void refreshStudents() {
        mStudentDB.retrieveStudentObjects();
    }
    @Override
    public int getCount() {
        return mStudentDB.getStudents().size();
    }

    @Override
    public Object getItem(int i) {
        return mStudentDB.getStudents().get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View row_view;

        if (view == null) {
            count++;
            LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
            row_view = inflater.inflate(R.layout.student_row, viewGroup, false);
        } else row_view = view;

        Student student = mStudentDB.getStudents().get(i);

        TextView firstNameView = row_view.findViewById(R.id.first_name);
        firstNameView.setText(student.getFirstName());
        Log.d("SummaryLVAdapter", "getView: " + student.getFirstName());
        TextView lastNameView = row_view.findViewById(R.id.last_name);
        lastNameView.setText(" " + student.getLastName());
        row_view.setTag(new Integer(i));
        row_view.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //
                        Toast.makeText(view.getContext(), "row_view was touched"  , Toast.LENGTH_SHORT).show();


                        // Page Navigation
                        Intent intent = new Intent(view.getContext(), StudentDetailActivity.class);
                        intent.putExtra("PersonIndex", ((Integer) view.getTag()).intValue());
                        view.getContext().startActivity(intent);
                    }
                }
        );
        return row_view;
    }
}
